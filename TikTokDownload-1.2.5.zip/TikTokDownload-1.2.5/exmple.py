#用户主页批量下载
import TikTokMulti as MTK

MTK.TikTok()

#单视频下载
import TikTokDownload as TK

TK.video_download(TK.main())

